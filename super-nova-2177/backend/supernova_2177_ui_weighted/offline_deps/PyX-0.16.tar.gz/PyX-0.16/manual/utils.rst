.. only:: doctest

   .. module:: utils

   .. autofunction:: kwsplit 
