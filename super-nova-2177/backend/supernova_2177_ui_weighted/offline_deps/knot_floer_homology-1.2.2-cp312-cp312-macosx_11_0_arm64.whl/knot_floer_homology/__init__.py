__version__ = '1.2.2'

from .hfk import pd_to_morse, pd_to_hfk

